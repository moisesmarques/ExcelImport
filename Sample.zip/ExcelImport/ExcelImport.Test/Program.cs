﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelImport.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            Workbook arquivoCompleto = WorkbookFactory.LoadFile(string.Concat(path, "\\", "valores.xlsx"));
            Worksheet planilha = arquivoCompleto.Worksheets.FirstOrDefault();
            foreach (var row in planilha.Rows)
                Console.WriteLine(string.Format("Column1: {0}, Column2: {1}", row.Cells[0].Value, row.Cells[1].Value));

            Console.ReadKey();
        }
    }
}
